import * as formulajs from "@formulajs/formulajs";

const SUPPORTED_FORMULAS = Object.keys(formulajs);

export default SUPPORTED_FORMULAS;
