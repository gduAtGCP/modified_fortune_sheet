---
home: true
heroText: FortuneSheet
tagline: Configuration Document · API · Tutorial
actionText: Get Started →
actionLink: /guide/
features:
- title: Powerful Features
  details: Contains a large number of commonly used spreadsheet functions to replace your excel
- title: Simple Configuration
  details: Get started with minimal configuration
- title: Open Source
  details: Community driven, work together to improve your ideas
footer: MIT Licensed
---